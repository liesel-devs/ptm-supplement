__version_info__ = (0, 4, 2, "dev")
__version__ = "0.4.2-dev"
