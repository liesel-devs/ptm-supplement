class Roles:
    basis: str = "gam_basis"
    coef_smooth: str = "gam_coef_smooth"
    coef_linear: str = "gam_coef_linear"
    variance_smooth: str = "gam_variance_smooth"
    scale_smooth: str = "gam_scale_smooth"
    term_smooth: str = "gam_term_smooth"
    term_linear: str = "gam_term_linear"
    intercept: str = "gam_intercept"
